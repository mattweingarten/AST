This page has moved [here](https://google.github.io/oss-fuzz/advanced-topics/reproducing)
