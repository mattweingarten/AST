---
layout: default
title: Getting started
has_children: true
nav_order: 2
permalink: /getting-started/
---

# Getting started
These pages walk you through the process of integrating your open source project
with OSS-Fuzz.
