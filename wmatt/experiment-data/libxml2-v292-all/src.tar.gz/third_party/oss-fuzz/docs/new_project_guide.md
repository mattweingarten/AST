This page has moved [here](https://google.github.io/oss-fuzz/getting-started/new-project-guide/)
