import itertools

from analysis.coverage_data_utils import get_fuzzer_benchmark_covered_regions_and_key

if __name__ == '__main__':
    key, data = get_fuzzer_benchmark_covered_regions_and_key('aflplusplus_ast_o0', 'libpng-1.2.56',
                                                 '/home/b/bdata/beandata/eth/projects_eth/eth-sm04-ast/repo/matt-AST/bean/benchmarks/experiment-data/exp-2022-04-22-00-58-08-libpng-4h')

    result = itertools.starmap(get_fuzzer_benchmark_covered_regions_and_key,
                               arguments)

    print(data)